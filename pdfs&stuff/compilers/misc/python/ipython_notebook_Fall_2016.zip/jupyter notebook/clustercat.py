#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
#import MDAnalysis
#import numpy as np

#%matplotlib inline
#import matplotlib.pyplot as plt

#protein = u.select_atoms("protein")
#u = MDAnalysis.Universe(PDB, XTC)
#with MDAnalysis.Writer("protein.xtc", protein.n_atoms) as W:
#    for ts in u.trajectory:
#        W.write(protein)

from __future__ import print_function
%matplotlib inline
import mdtraj as md
import numpy as np
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy
import pylab


t = md.load('4_nvt_50ns_its-cluster_Protein_noPBC.xtc', top='4_nvt_50ns_its-cluster_Protein_noPBC.gro')

t_subset = t[:500]
RMSD_CUTOFF=1.5

atom_indices = [a.index for a in t_subset.topology.atoms if a.name == 'CA']
distances = np.empty((t_subset.n_frames, t_subset.n_frames))
for i in range(t_subset.n_frames):
    distances[i] = md.rmsd(t_subset, t_subset, i, atom_indices=atom_indices)

linkage = scipy.cluster.hierarchy.average(distances)

plt.figure(figsize=(20,10))
plt.title('RMSD UPGMA hierarchical clustering')
_ = scipy.cluster.hierarchy.dendrogram(linkage, no_labels=True, count_sort='descendent', color_threshold=RMSD_CUTOFF)
pylab.savefig( "dendrogram.png" )

clusters = scipy.cluster.hierarchy.fcluster(linkage, RMSD_CUTOFF, criterion='distance')

print(clusters)

#tree = scipy.cluster.hierarchy.to_tree(linkage)


import collections
cluster_index = collections.defaultdict(list)

for i, cl in enumerate(clusters):
    cluster_index[cl].append(i)

cluster_reps = {}
for cl, frames in cluster_index.items():
    totdist = []
    for i in frames:
        tot = 0.0
        for j in frames:
            tot += distances[i, j]
        totdist.append(tot)
    m = min(totdist)
    rep = totdist.index(m)
    print(cl, frames[rep])
    cluster_reps[cl] = frames[rep]

print(cluster_reps)

for cl, rep in cluster_reps.items():
    frame = t_subset[rep]
    frame.save_pdb('cluster_%d_frame_%d.pdb'%(cl, rep))


#import msmbuilder.metrics
#import msmbuilder.clustering
#
#RMSD_metric = msmbuilder.metrics.RMSD()
#clusterer = msmbuilder.clustering.Hierarchical(RMSD_metric, [t], method='average')
#
#cluster_assignments = clusterer.get_assignments()
#
#print cluster_assignments



