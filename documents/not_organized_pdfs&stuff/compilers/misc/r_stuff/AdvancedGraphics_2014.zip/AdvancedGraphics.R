#Advanced graphics in R
#Basics to warm up with!

View(cars)
plot(cars, main="Cars:  Stopping Distance vs Speed (1920)", xlab="Speed (mph)", 
     ylab="Stopping Distance (ft)", col="blue", pch=19)


View(mtcars)

# Compare MPG distributions for cars with 
# 4,6, or 8 cylinders
# install package sm
library(sm)
attach(mtcars)

# create value labels 
cyl.f = factor(cyl, levels= c(4,6,8),
                labels = c("4 cylinder", "6 cylinder", "8 cylinder")) 

# plot densities 
sm.density.compare(mpg, cyl, xlab="Miles Per Gallon")
#function allows a set of univariate desnity estimates to be compared, 
#both graphically and formally in a permutation test of equality
title(main="MPG Distribution by Car Cylinders")

# add legend via mouse click
colfill = c("red", "green", "blue")

sm.density.compare(mpg, cyl, xlab="Miles Per Gallon")
title(main="MPG Distribution by Car Cylinders")
legend("topright", levels(cyl.f), fill=colfill)
legend("topright", levels(cyl.f),lty=c(1,2,3), col=colfill)

detach(mtcars)

# Boxplot of MPG by Car Cylinders 
boxplot(mpg~cyl,data=mtcars, main="Car Milage Data", 
        xlab="Number of Cylinders", ylab="Miles Per Gallon")

# Notched Boxplot of Tooth Growth Against 2 Crossed Factors
# boxes colored for ease of interpretation - great for visualization
boxplot(mpg~cyl, data=mtcars, notch=TRUE, 
        col=colfill,main="mpg vs cyl", xlab="cyl", ylab="mpg")
legend("topright", levels(cyl.f), fill=colfill)


# Violin Plots
#A violin plot is a combination of a box plot and a kernel density plot. 
#Specifically, it starts with a box plot. 
#It then adds a rotated kernel density plot to each side of the box plot.

library(vioplot)
x1 = mtcars$mpg[mtcars$cyl=="4"]
x2 = mtcars$mpg[mtcars$cyl=="6"]
x3 = mtcars$mpg[mtcars$cyl=="8"]
vioplot(x1, x2, x3, names=c("4 cyl", "6 cyl", "8 cyl"), col="gold")
title("Violin Plots of Miles Per Gallon")


# Enhanced Scatterplot of MPG vs. Weight 
# by Number of Car Cylinders 
# install package car
library(car) 
scatterplot(mpg ~ wt | cyl, data=mtcars, 
            xlab="Weight of Car", ylab="Miles Per Gallon", 
            main="Enhanced Scatter Plot", 
            labels=row.names(mtcars))

# High Density Scatterplot with Binning
library(hexbin)
x = rnorm(1000)
y = rnorm(1000)
bin = hexbin(x, y) 
plot(bin, main="Hexagonal Binning")

# 3D Scatterplot
library(scatterplot3d)
attach(mtcars)
scatterplot3d(wt,disp,mpg, main="3D Scatterplot")

#highlight.3d=TRUE points will be drawn in different 
#colors related to y coordinates (only if type = "p" 
#or type = "h", else color will be used).
scatterplot3d(wt,disp,mpg, pch=16, highlight.3d=TRUE,
              type="p", main="3D Scatterplot")

# 3D Scatterplot with Coloring and Vertical Lines
# and Regression Plane 
s3d = scatterplot3d(wt,disp,mpg, pch=16, highlight.3d=TRUE,
                    type="h", main="3D Scatterplot")
fit = lm(mpg ~ wt+disp) 
s3d$plane3d(fit)


# Spinning 3d Scatterplot
library(rgl)

plot3d(wt, disp, mpg, col="red", size=3)

detach(mtcars)

#more 3d grahics
View(volcano)
#This function draws perspective plots 
#of a surface over the x-y plane. persp is a generic function.
persp(volcano)
persp(volcano, col = "green", phi=40,theta=50)
#theta, phi = viewing angles #play with the angles


##################

#BREAK!

# Lattice Examples

library(lattice)

#Draw Conditional Scatter Plot Matrices and Parallel Coordinate Plots

attach(mtcars)


# kernel density plot
#Draw Histograms and Kernel Density Plots, possibly conditioned on other variables.
densityplot(~mpg, main="Density Plot",xlab="Miles per Gallon")

# kernel density plots by factor level
densityplot(~mpg|cyl, main="Density Plot by Number of Cylinders",xlab="Miles per Gallon")

# kernel density plots by factor level (alternate layout)
densityplot(~mpg|cyl,main="Density Plot by Numer of Cylinders",xlab="Miles per Gallon",
            layout=c(1,3))

# boxplots for each combination of two factors
bwplot(cyl~mpg|gear, ylab="Cylinders", xlab="Miles per Gallon",main="Mileage by Cylinders and Gears",
       layout=(c(1,3)))

# scatterplots for each combination of two factors
xyplot(mpg~wt|cyl*gear,main="Scatterplots by Cylinders and Gears",
       ylab="Miles per Gallon", xlab="Car Weight")

# 3d scatterplot by factor level
cloud(mpg~wt*qsec|cyl, main="3D Scatterplot by Cylinders")

# dotplot for each combination of two factors
dotplot(cyl~mpg|gear,main="Dotplot Plot by Number of Gears and Cylinders",
        xlab="Miles Per Gallon")

# scatterplot matrix
#Draw Conditional Scatter Plot Matrices and Parallel Coordinate Plots
splom(mtcars[c(1,3,4,5,6)],main="MTCARS Data")


detach(mtcars)       

###################

# ggplot2 examples
library(ggplot2)

# Kernel density plots for mpg
library(MASS)

#qplot is the basic plotting function in the ggplot2 package, 
#designed to be familiar if you're used to plot from the base package.
# grouped by number of cyl (indicated by color)
qplot(MPG.city, data=Cars93, geom="density", fill=Cylinders, alpha=I(.5),
      main="Distribution of Gas Milage-City", xlab="Miles Per Gallon",
      ylab="Density")

#alpha=I(.5) = transparency

# Scatterplot of mpg vs. hp for each cyl
qplot(Horsepower, MPG.city, data=Cars93, 
      size=I(3), 
      color=Cylinders,
      xlab="Horsepower", ylab="Miles per Gallon-City")

#shape=am, color=am, bases it by our factor, am is a column heading in mtcars

# Separate regressions of mpg on weight for each number of cylinders
qplot(Weight, MPG.city, data=Cars93, geom=c("point", "smooth"),
      method="lm", formula=y~x, color=Cylinders,
      main="Regression of MPG on Weight",
      xlab="Weight", ylab="Miles per Gallon  - City")

#let's clean it up! remove "point"
#no points
qplot(Weight, MPG.city, data=Cars93, geom="smooth",
      method="lm", formula=y~x, color=Cylinders,
      main="Regression of MPG on Weight",
      xlab="Weight", ylab="Miles per Gallon  - City")

# Boxplots of mpg by number of cylinders

# observations (points) are overlayed and jittered
qplot(Cylinders, MPG.city, data=Cars93, geom=c("boxplot", "jitter"),
      fill=Cylinders, main="Mileage by Gear Number",
      xlab="", ylab="Miles per Gallon") 

# observations (no points) are overlayed and jittered
qplot(Cylinders, MPG.city, data=Cars93, geom="boxplot",
      fill=Cylinders, main="Mileage by Gear Number",
      xlab="", ylab="Miles per Gallon") 


###mosaic plots
# Mosaic Plot Example
#A mosaic plot is a graphical display that allows you 
#more exploratory analyses
#to examine the relationship among two or more categorical variables. 

library(vcd)
View(HairEyeColor)
mosaic(HairEyeColor, shade=TRUE, legend=TRUE)
mosaic(HairEyeColor, shade=FALSE)

#association plot
# Association Plot Example

assoc(HairEyeColor, shade=TRUE)

#interact with a scatterplot

# Interacting with a scatterplot 

plot(mtcars$hp, mtcars$mpg) # scatterplot
#identify points
identify(mtcars$hp, mtcars$mpg, labels=row.names(mtcars)) # identify points 
coords = locator(type="l") # add lines
coords # display list


#We will not go over the following during the seminar, however, take a 
#look at some very complex animated graphing we can do in R

#An animated diagram showing iterations of the equation used 
#to generate the Mandelbrot set, a fractal first studied by 
#Beno�t Mandelbrot in 1979. The animation shows the values of 
#Z for first 20 iterations of the equation
#Z_{n+1} = Z_n^2+c, 
##where c is a complex variable.
#Mandelbrot set graphics are usually generated using the so-called 
#"escape algorithm", where color is assigned according to the number 
#of iterations it took for the equation to diverge past a pre-set limit, 
#and black color is used for regions that never diverge. This, however, 
#is a plot of a much simpler quantity: the actual values of the equation 
#at the first 20 iterations. Every pixel in the image corresponds to a 
#different value of a complex constant c ranging from -2.2 to 1 on the 
#real axis (horizontal) and from -1.2i to 1.2i on the imaginary axis 
#(vertical). Z is initialized to 0. At each iteration, the next value of 
#Z is calculated using the equation above.
This graphic was generated with 13 lines of code in the R language 
#(see below for the code). For each point, the magnitude (aka absolute value) of Z is calculated, than scaled using an exponential function to emphasize fine detail, and finally mapped to color palette (jetColors). Dark red is a very low number, dark blue is a very high number. The deep blue region "squeezing" in the boundaries of the fractal is the region where Z value diverges to infinity.

library(caTools)
jet.colors = colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000")) 
m = 600
C = complex( real=rep(seq(-1.8,0.6, length.out=m), each=m ), 
             imag=rep(seq(-1.2,1.2, length.out=m), m ) ) 
C = matrix(C,m,m)
Z = 0 
X = array(0, c(m,m,20))
for (k in 1:20) { 
  Z = Z^2+C 
  X[,,k] = exp(-abs(Z)) 
} 
write.gif(X, "Mandelbrot.gif", col=jet.colors, delay=100)

