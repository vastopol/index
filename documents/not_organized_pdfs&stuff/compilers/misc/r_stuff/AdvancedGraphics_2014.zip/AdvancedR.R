#Advanced Topics in R

#some basic "advanced topics" - playing with dataframes, lists, and matrices

#appending vectors

v=c(1,2,3)
v
v=c(v,4)
v
w=c(5,6,7,8)
v=c(v,w)
v

#inserting data into a vetor

append(1:10, 99, after=5)

#remove an element from a list/matrix

library(MASS)
newdata=Cars93  #{MASS}
View(newdata)
newdata$Max.Price = NULL  #removed Max.Price
View(newdata)

#defining groups via a factor

v= c(40,2,83,28,58)
f=factor(c("A", "C", "C", "B", "C")) #creates a factor
v
f

#split vector by groups
groups = split(v,f)  #unsplit reverses
groups

##

#split vector by goups, but if all vectors have the same length, convert to a 
#data frame

groups=unstack(data.frame(v,f)) #did the same thing as split
groups

#need package {MASS}
library(MASS)
#Let's use the dataset in R, Cars93, to practice

View(Cars93)
gas=split(Cars93$MPG.city, Cars93$Origin)
gas

median(gas[[1]]) # double bracks allows to choose the subset of data points rather than a specific data point
median(gas[[2]])
mean(gas[[2]])
sd(gas[[2]])



#getting R to do multiple things in a "string" or a "loop"

# simple looping -- Applying a function to each list element


#Mean temperature by monrh

lapply(airquality, mean) #returns a list


sapply(airquality, mean) #returns a vector
apply(airquality, 2, mean) #returns a vector #same as above, 
#replace the above 2 with a 1 to apply by row rather than column

sapply(airquality, range) #returns a matrix


## Creates a sample list 
mylist <- as.list(iris[1:3,1:3])
mylist

## Compute sum of each list component and return result as list
lapply(mylist, sum)

## Compute sum of each list component and return result as vector
sapply(mylist, sum)



#subset which columns you are interested in 
AvgTempMonth=tapply(airquality$Temp, airquality$Month, mean)
AvgTempMonth

############
#some statistics


# Multiple Linear Regression Example 
fit = lm(mpg ~ disp + hp + drat, data=mtcars)
summary(fit) # show results

# Other useful functions 
coefficients(fit) # model coefficients
confint(fit, level=0.95) # CIs for model parameters 
fitted(fit) # predicted values
residuals(fit) # residuals
anova(fit) # anova table 
vcov(fit) # covariance matrix for model parameters 
influence(fit) # regression diagnostics

#Generalized linear models

?family

library(survival)
View(lung)

fit2 = glm(time~age+sex,data=lung,family="poisson")

summary(fit2) # display results
confint(fit2) # 95% CI for the coefficients


predict(fit2, type="response") # predicted values
residuals(fit2, type="deviance") # residuals



#################



# For Loops are very powerful! -- simple example
for(i in 1:100){ #loops 100 times
  print("Hello world!") #prints "Hello World!" each time
  print(i*i) #prints i*i after each Hellow World!
}

#lets use a data set, iris

View(iris)


#Let's do a for lopp and write our data
#we are going to do simple regression analyses over multiple groups

dat = iris

out.rp = matrix(NA,ncol=5,nrow=length(unique(as.character(dat$Species))))
out.rp[,1] <- unique(as.character(dat$Species))
out.rp

for (i in 1:nrow(out.rp)) {
  X1<-dat$Sepal.Width[which(as.character(dat$Species)==as.character(out.rp[i,1]))]
  X2<-dat$Petal.Length[which(as.character(dat$Species)==as.character(out.rp[i,1]))]
  Y<-dat$Sepal.Length[which(as.character(dat$Species)==as.character(out.rp[i,1]))]
  
  
  md<-lm(Y~ X1 + X2)
  out.rp[i,2:5]=c(summary(md)$coefficients[2,1],summary(md)$coefficients[2,4],
                  summary(md)$coefficients[3,1],summary(md)$coefficients[3,4])
  #slope, pvalue, slope, pvalue
}

#let's look at what we created
out.rp
#let's look at at how you take out the data
summary(md) #just gives us the summary from the last run in the loop
summary(md)$coefficients[2,1] #slope of X1
summary(md)$coefficients[2,4] #pvalue of X1
summary(md)$coefficients[3,1] #slope of X2
summary(md)$coefficients[3,4] #pvalue of X2

# you could always create a bigger matrix and save more values, such as standard errors

#let's rename column headings
colnames(out.rp) = c("B1","P1","B2","P2") #void original
colnames(out.rp) = c("species","B1","P1","B2","P2")

#let's write a table
write.table(out.rp,"Practiceloop.txt") 
  #this will automatically put it in your directory

#open with microsoft excel --- show how to create a table

##############################
###YAY - let's take a break!
##############################

#Defining a Function!

#one line looks like:  function(param_1,..., param_n)expr

#example of a one-lined function
#R does not have a built in function for calculating the 
#coefficient of variation --- let's make one!

cv=function(x) sd(x)/mean(x)
#above is our new function
#below is a list to apply the new funciton
lst=c(34,32,23,65,44,65,23,87,54,34,65,45,78)
cv(lst)

#can we apply our new function to multiple columns? Yes!
newCars=Cars93[,4:7]
lapply(newCars, cv)

#Example of a multi-lined function

#Suppose you want to present fractional 
#numbers as percentages, nicely rounded to one decimal digit. 

Percent = function(x){
  percent = round(x * 100, digits = 1)
  result = paste(percent, "%", sep = "") 
  #if no sep = "", there would be a space between # and %
  return(result)
}

Percent(213/456)

#let's say you want to make multiple plots with the same arguments, 
#but you do not want to write them each time!

redplot = function(z, y) {
  plot(z,y, col = "red", pch = 15)
} 

redplot(iris$Sepal.Length,iris$Sepal.Width)

#ordinary plot looks like
plot(iris$Sepal.Length,iris$Sepal.Width)

#######################

#plotting time series

#download tui file


tui = read.csv("tui.csv", header=T, dec=",", sep=";")
View(tui)

plot(tui[,5],type="l")
plot(tui[,5], type="l",
     lwd=2, col="red", xlab="time", 
     ylab="closing values",main="TUI AG", ylim=c(0,60) )


#Linear Filtering of Time Series
#A key concept in traditional time series analysis is the decomposition of a given
#time series into a trend

library(TSA)
plot(tui[,5],type="l")
tui.1 <- filter(tui[,5],filter=rep(1/5,5))
tui.2 <- filter(tui[,5],filter=rep(1/25,25))
tui.3 <- filter(tui[,5],filter=rep(1/81,81))
lines(tui.1,col="red")
lines(tui.2,col="purple")
lines(tui.3,col="blue")

#filter() Applies linear filtering to a univariate time 
series or to each series separately of a multivariate time series.

#calculate a moving average
library(zoo)

ts1=zoo(tui[,5]) #creates a time series
plot(ts1)


ma=rollmean(ts1, 5)
plot(ma)
ma=rollmean(ts1, 25)
plot(ma)
ma=rollmean(ts1, 81)
plot(ma)

#############

##################

# Lattice Examples

library(lattice)
attach(mtcars)
View(mtcars)

# create factors with value labels
gear.f<-factor(gear,levels=c(3,4,5),labels=c("3gears","4gears","5gears"))

cyl.f <-factor(cyl,levels=c(4,6,8), labels=c("4cyl","6cyl","8cyl"))

# kernel density plot
densityplot(~mpg, main="Density Plot",xlab="Miles per Gallon")

# kernel density plots by factor level
densityplot(~mpg|cyl.f, main="Density Plot by Number of Cylinders",xlab="Miles per Gallon")

# kernel density plots by factor level (alternate layout)
densityplot(~mpg|cyl.f,main="Density Plot by Numer of Cylinders",xlab="Miles per Gallon",
            layout=c(1,3))

# boxplots for each combination of two factors
bwplot(cyl.f~mpg|gear.f, ylab="Cylinders", xlab="Miles per Gallon",main="Mileage by Cylinders and Gears",
       layout=(c(1,3)))

# scatterplots for each combination of two factors
xyplot(mpg~wt|cyl.f*gear.f,main="Scatterplots by Cylinders and Gears",
       ylab="Miles per Gallon", xlab="Car Weight")

# 3d scatterplot by factor level
cloud(mpg~wt*qsec|cyl.f, main="3D Scatterplot by Cylinders")

# dotplot for each combination of two factors
dotplot(cyl.f~mpg|gear.f,main="Dotplot Plot by Number of Gears and Cylinders",
        xlab="Miles Per Gallon")

# scatterplot matrix
splom(mtcars[c(1,3,4,5,6)],main="MTCARS Data")


detach(mtcars)       

###################

# ggplot2 examples
library(ggplot2)

# create factors with value labels
mtcars$gear <- factor(mtcars$gear,levels=c(3,4,5),labels=c("3gears","4gears","5gears"))

mtcars$am <- factor(mtcars$am,levels=c(0,1),labels=c("Automatic","Manual"))

mtcars$cyl <- factor(mtcars$cyl,levels=c(4,6,8), labels=c("4cyl","6cyl","8cyl"))

# Kernel density plots for mpg

# grouped by number of gears (indicated by color)
qplot(mpg, data=mtcars, geom="density", fill=gear, alpha=I(.5),
      main="Distribution of Gas Milage", xlab="Miles Per Gallon",
      ylab="Density")
#alpha=I(.5) = transparency

# Scatterplot of mpg vs. hp for each combination of gears and cylinders
# in each facet, transmittion type is represented by shape and color
qplot(hp, mpg, data=mtcars, 
      facets=gear~cyl, size=I(3),shape=am, color=am,
      xlab="Horsepower", ylab="Miles per Gallon")
#shape=am, color=am, bases it by our factor, am

# Separate regressions of mpg on weight for each number of cylinders
qplot(wt, mpg, data=mtcars, geom=c("point", "smooth"),
      method="lm", formula=y~x, color=cyl,
      main="Regression of MPG on Weight",
      xlab="Weight", ylab="Miles per Gallon")

# Boxplots of mpg by number of gears
# observations (points) are overlayed and jittered
qplot(gear, mpg, data=mtcars, geom=c("boxplot", "jitter"),
      fill=gear, main="Mileage by Gear Number",
      xlab="", ylab="Miles per Gallon") 



