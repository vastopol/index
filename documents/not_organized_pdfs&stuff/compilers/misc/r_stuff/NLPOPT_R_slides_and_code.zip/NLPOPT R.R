
###################Examples with quadprog##################  


####Simple constrained maximization######


plot(0, 0, xlim = c(-1,4), ylim = c(-1,4), type = "n", xlab = "x", ylab = "y", main="Feasible Region")
rect(-1.2, -1.2, 1, 2,col="grey", border=par("fg"), lty=NULL, xpd=NA, bg="grey")

        
plot(0, 0, xlim = c(-1,4), ylim = c(-1,4), type = "n", xlab = "x", ylab = "y", main="Solution")
require(plotrix)
draw.circle(2,3,0.5,border="blue")
draw.circle(2,3,1,border="blue")
draw.circle(2,3,1.325,border="blue")
rect(-1.2, -1.2, 1, 2, border=par("fg"), lty=NULL, xpd=NA, col="grey")
points(1,2, pch=21, bg="blue")
points(2,3, col="blue")

library(quadprog)

#max f(x)=-(x-2)^2-(y-3)^2+1 s.t. x<=1 and y<=2

Dmat <- matrix(c(2, 0, 0, 2),ncol = 2 , byrow=TRUE)
dvec <- c(4, 6)
Amat <- matrix(c(-1, 0, 0, -1), ncol = 2 , byrow=TRUE)
Amat=t(Amat)
bvec <- c(-1, -2)
solve.QP(Dmat,dvec,Amat,bvec=bvec,meq=0)
  
  
n=250
x1=rnorm(n,mean=1,sd=2)
x2=rnorm(n,mean=1,sd=2)
error=rnorm(n, mean=0,sd=1)
a=1.2
b=-0.5
constant=3
y=constant+a*x1+b*x2+error
forcons=rep(1,n)
X=cbind(forcons,x1,x2)
c=mean(y)

Dmat <- t(X)%*%X
dvec <- t(X)%*%y
Amat <- matrix(c(0, -c, -1,
                 0, 0, 0,
                 0, 0, 0
), ncol = 3 , byrow=TRUE)
Amat=t(Amat)
bvec <- c(0, 0, 0)
solve.QP(Dmat,dvec,Amat,bvec=bvec,meq=0)
#Notice the unconstrained solution and the results from OLS
lm(y~x1+x2)




************************************************************************************************************************

#Example for how to set up nonlinear constraints in an optimization problem with Rsolnp. Only works for small data sets


library(Rsolnp)

n=250
x1=rnorm(n,mean=1,sd=2)
x2=rnorm(n,mean=1,sd=2)
error=rnorm(n, mean=0,sd=1)
a=1.2
b=-0.5
constant=3
y=constant+a*x1+b*x2+error
forcons=rep(1,n)
X=cbind(forcons,x1,x2)

#Minimize residual sum of squares
fn <- function(param) {
  sum((y-param[1]*x1-param[2]*x2-param[3]*forcons)^2)
}

#Subject to the nonlinear constraint...Slutsky condition
# constraint z1 requires that we flip all signs from negative to positive.
eqn <- function(param) { 
  z1=x1*(param[1])^2+param[1]*param[2]*x2+param[1]*param[3]+param[2]
  return(c(z1))
}


x0 <- c(0.2, -0.7,1) # setup init values
slutskyupperbound=rep(0,n)
slutskylowerbound=rep(-3,n)
LBD=c(-2,-2,0)
UBD=c(3,3,4)
sol1 <- solnp(x0, fun = fn, ineqfun = eqn, ineqLB=slutskylowerbound,ineqUB=slutskyupperbound,LB=LBD,UB=UBD)
sol1$pars
sol1$convergence

#####gosol example############### The distr command has "1" which means randomly sample in the feasible space according to a uniform distribution. Other distributions are available.

sol2=gosolnp(fun=fn, ineqfun = eqn,
             ineqLB = slutskylowerbound, ineqUB =slutskyupperbound , LB = LBD, UB = UBD,
             distr = rep(1, n), n.restarts = 5, n.sim = 10, rseed = 15)

#############R example############

# POWELL Problem 
fn1=function(x){ 
  exp(x[1]*x[2]*x[3]*x[4]*x[5])
} 
eqn1=function(x){ 
  z1=x[1]*x[1]+x[2]*x[2]+x[3]*x[3]+x[4]*x[4]+x[5]*x[5] 
  z2=x[2]*x[3]-5*x[4]*x[5]
  z3=x[1]*x[1]*x[1]+x[2]*x[2]*x[2] 
  return(c(z1,z2,z3))
} 
x0 = c(-2, 2, 2, -1, -1) 
powell=solnp(x0, fun = fn1, eqfun = eqn1, eqB = c(10, 0, -1)) 
powell$pars
powell$convergence


################nleqslv for solving systems of nonlinear equations. Example from R#############

library(nleqslv)

#The system of equations
dslnex <- function(x) {
  y <- numeric(2)
  y[1] <- x[1]^2 + x[2]^2 - 2
  y[2] <- exp(x[1]-1) + x[2]^3 - 2
  y
}

#solve the system without providing the Jacobian. We need to provide starting values
xstart <- c(2,0.5)
#Evaluate both equations at the starting values
fstart <- dslnex(xstart)
nleqslv(xstart, dslnex, control=list(btol=.01))

#Jacobian-matrix of first derivatives
jacdsln <- function(x) {
  n <- length(x)
  Df <- matrix(numeric(n*n),n,n)
  Df[1,1] <- 2*x[1]
  Df[1,2] <- 2*x[2]
  Df[2,1] <- exp(x[1]-1)
  Df[2,2] <- 3*x[2]^2
  Df
}

#Providing the jacobian.
nleqslv(xstart, dslnex, jacdsln, method="Broyden", global="none", control=list(trace=1, stepmax=2))


###################################Global minimization#################


x<-seq(-5.12,5.12,length=100)
y<-x
f<-function(x,y) { 
  20+(x^2-10*cos(2*pi*x))+(y^2-10*cos(2*pi*y)) 
}
z<-outer(x,y,f)
z[is.na(z)]<-1
persp(x,y,z,theta=30,phi=30,expand=0.5,col="blue",ltheta=90,shade=0.50,ticktype="detailed",d=5,r=1)


#Notice that we dont need to give starting values, just bounds
Rastrigin<-function(x) {
  sum(x^2 -10*cos(2*pi*x))+10*length(x)
}
dimension<-5
lower<-rep(-5.12, dimension)
upper<-rep(5.12, dimension)
require(GenSA)
global.min<-0
tol<-1e-13
set.seed(1234)
ctrl<-list(threshold.stop=global.min+tol, verbose=TRUE)
aGenSA1<- GenSA(lower = lower, upper = upper, fn = Rastrigin, control=ctrl)
print(aGenSA1[c("value", "par", "counts")])


###########Solving the previous sytem of equations#####

system<-function(x) {
  (x[1]^2+x[2]^2-2)^2+(exp(x[1]-1)+x[2]^3-2)^2
}

#One out of two solutions
dimension<-2
lower<-rep(-3, dimension)
upper<-rep(3, dimension)
global.min<-0
tol<-1e-13
set.seed(1234)
ctrl<-list(threshold.stop=global.min+tol, verbose=TRUE)
aGenSA1<- GenSA(lower = lower, upper = upper, fn = system, control=ctrl)
print(aGenSA1[c("value", "par", "counts")])

#The other solution
set.seed(1)
aGenSA1<- GenSA(lower = lower, upper = upper, fn = system, control=ctrl)
print(aGenSA1[c("value", "par", "counts")])


#####################################Univariate root finding################

library(rootSolve)

#Single root - rootSolve

alpha1=1
alpha2=0.2

efn <- function(x,alpha) {
  exp(-x*alpha)-0.2
}
zfn <- function(x) {
  x*0
}

tint <-c(0,50)
curve(efn(x, alpha=alpha1), from=tint[1], to=tint[2],lty=2,main="f(x)=exp(-x*alpha)-0.2", ylab='f(x)')
title(sub="Dashed for alpha=1 and dotted for alpha=0.2")
curve(zfn,add=TRUE)
curve(efn(x,alpha=alpha2), add=TRUE, lty=3, col='blue')

uni <- uniroot(efn, tint, alpha=alpha1)
a=uni$root
a
points(a, 0, pch = 16)

uni2 <- uniroot(efn, tint, alpha=alpha2)
b=uni2$root
b
points(b, 0, pch = 16, col='blue')

#Let's verify that this is the solution we would get by hand:
solalpha1=-log(0.2)/alpha1
solalpha2=-log(0.2)/alpha2
solalpha1
a
solalpha2
b


#Multiple roots on one variable - rootSolve

efn1 <- function(x,alpha) {
  cos(2*x)^alpha
}

curve(efn1(x, alpha=alpha1), 0, 8)
abline(h = 0, lty = 3)


Allmultiple <- uniroot.all(efn1, c(0,8), alpha=alpha1,n=5)
points(Allmultiple, y=rep(0,length(Allmultiple)), pch = 16, col='blue')


#########Introduction###############

efn2 <- function(x) {
  x^5 -x + 1
}

curve(efn2(x), -2, 1, main="Real solution (approx) -1.167291")
abline(h = 0, lty = 3)


Allmultiple <- uniroot.all(efn2, c(-2,1),n=2)
points(Allmultiple, y=rep(0,length(Allmultiple)), pch = 16, col='blue')
Allmultiple











